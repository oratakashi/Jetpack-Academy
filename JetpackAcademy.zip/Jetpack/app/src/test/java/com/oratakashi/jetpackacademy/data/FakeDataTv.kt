package com.oratakashi.jetpackacademy.data

class FakeDataTv {
    fun generateTv(): List<DataTv> {
        return ArrayList<DataTv>()
    }
}