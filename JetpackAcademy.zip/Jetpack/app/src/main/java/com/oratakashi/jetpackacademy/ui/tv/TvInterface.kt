package com.oratakashi.jetpackacademy.ui.tv

import com.oratakashi.jetpackacademy.data.DataTv

interface TvInterface {
    fun onClickMenu(data: DataTv)
}