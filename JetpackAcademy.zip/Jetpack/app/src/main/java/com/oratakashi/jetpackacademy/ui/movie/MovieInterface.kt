package com.oratakashi.jetpackacademy.ui.movie

import com.oratakashi.jetpackacademy.data.DataMovie

interface MovieInterface {
    fun onClickMenu(data: DataMovie)
}